if (location.search === "?react-live") {
    require("@tiny-i18n/react-live/register.js");
    require("@tiny-i18n/react-live/lib/style.css");
  }
  
  require("./entry");
  